package it.uniroma3.siw.service;

import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Giocatore;
import it.uniroma3.siw.model.Squadra;
import it.uniroma3.siw.repository.GiocatoreRepository;
import it.uniroma3.siw.repository.SquadraRepository;
import jakarta.transaction.Transactional;

@Service
public class SquadraService {

    @Autowired
    GiocatoreRepository giocatoreRepository;

    @Autowired
    SquadraRepository squadraRepository;

    @Transactional
    public void createSquadra(Squadra squadra){

    	this.squadraRepository.save(squadra);
    }
    
    //cambia i dettagli del prodotto,come prezzo, nome
    @Transactional
    public void editDetailsToSquadra(Squadra squadra) {
        // Recupera il prodotto esistente dal repository utilizzando l'ID
        Squadra existingSquadra = squadraRepository.findById(squadra.getId()).orElse(null);

        if (existingSquadra != null) {
            // Aggiorna i dettagli del prodotto con i nuovi valori
            existingSquadra.setNome(squadra.getNome());
            existingSquadra.setAnnoFondazione(squadra.getAnnoFondazione());
            existingSquadra.setIndirizzoSede(squadra.getIndirizzoSede());

            // Salva le modifiche nel repository
            squadraRepository.save(squadra);
        }
    }
    
    @Transactional
    public void setGiocatoreToSquadra(Squadra squadra, Long squadraId) {
        Giocatore giocatore = this.giocatoreRepository.findById(squadraId).get();

        giocatore.setSquadra(squadra);
        squadra.getGiocatori().add(giocatore);

        this.giocatoreRepository.save(giocatore);
        this.squadraRepository.save(squadra);
    }

    @Transactional
    public void removeGiocatoreToSquadra(Squadra squadra, Long squadraId) {
        Giocatore giocatore = this.giocatoreRepository.findById(squadraId).get();

        giocatore.setSquadra(null);
        squadra.getGiocatori().remove(giocatore);

        this.giocatoreRepository.save(giocatore);
        this.squadraRepository.save(squadra);
    }

	public Iterable<Squadra> findAllSquadre() {
		
		return this.squadraRepository.findAll();
	}

	public Optional<Squadra> findById(Long squadraId) {
		
		return this.squadraRepository.findById(squadraId);
	}


}

    
