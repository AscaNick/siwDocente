package it.uniroma3.siw.controller;

import java.security.Principal;
import java.util.HashSet;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import it.uniroma3.siw.controller.validator.GiocatoreValidator;
import it.uniroma3.siw.controller.validator.PresidenteValidator;
import it.uniroma3.siw.controller.validator.SquadraValidator;
import it.uniroma3.siw.model.Giocatore;
import it.uniroma3.siw.model.Presidente;
import it.uniroma3.siw.model.Squadra;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.GiocatoreRepository;
import it.uniroma3.siw.repository.PresidenteRepository;
import it.uniroma3.siw.repository.SquadraRepository;
import it.uniroma3.siw.service.GiocatoreService;
import it.uniroma3.siw.service.SquadraService;
import it.uniroma3.siw.service.UserService;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;
@Controller
public class AdminController {
	
	 @Autowired
	 private SquadraRepository squadraRepository;
	 @Autowired
	 private GiocatoreRepository giocatoreRepository;
	 @Autowired
	 private PresidenteRepository presidenteRepository;
	 @Autowired
	 private SquadraValidator squadraValidator;
	 @Autowired
	 private GiocatoreValidator giocatoreValidator;
	 @Autowired
	 private PresidenteValidator presidenteValidator;
	 @Autowired
	 private SquadraService squadraService;
	 @Autowired
	 private UserService userService;
	 @Autowired
	 private GiocatoreService giocatoreService;

	 @GetMapping("/admin/formNewSquadra")
	 public String newSquadra(Model model){
		 model.addAttribute("squadra",new Squadra());
		 return "/admin/formNewSquadra.html";
	 }
	 
	 @PostMapping("/admin/uploadSquadra")
	 public String newSquadra(Model model, @Valid @ModelAttribute("squadra") Squadra squadra, BindingResult bindingResult){       
		 this.squadraValidator.validate(squadra,bindingResult);
		 if(!bindingResult.hasErrors()){
			 this.squadraService.createSquadra(squadra);  
			 model.addAttribute("squadra", squadra);
			 model.addAttribute("userDetails", this.userService.getUserDetails());
			 return "squadra.html";
		 } else {
			 return "/admin/formNewSquadra.html";
		 }
	 }
	  @GetMapping("/admin/formNewPresidente")
	    public String formNewPresidente(Model model){
	        model.addAttribute("presidente",new Presidente());
	        return "/admin/formNewPresidente.html";
	    }
	  @PostMapping("/admin/presidente")
	    public String newPresidente(Model model,@Valid @ModelAttribute("presidente") Presidente presidente, BindingResult bindingResult) {  
	        this.presidenteValidator.validate(presidente, bindingResult);
	        if(!bindingResult.hasErrors()){
	            this.presidenteRepository.save(presidente);

	            model.addAttribute("presidente", presidente);
	            model.addAttribute("userDetails", this.userService.getUserDetails());
	            return "index.html";
	        }
	        else {
	            return "/admin/formNewPresidente.html";
	        }
	    }
	  @GetMapping("/admin/formNewGiocatore")
	    public String formNewGiocatore(Model model){
	        model.addAttribute("giocatore",new Giocatore());
	        return "/admin/formNewGiocatore.html";
	    }
	  
	  @PostMapping("/admin/giocatore")
	    public String newGiocatore(Model model,@Valid @ModelAttribute("giocatore") Giocatore giocatore, BindingResult bindingResult) {  
	        this.giocatoreValidator.validate(giocatore, bindingResult);
	        if(!bindingResult.hasErrors()){
	            this.giocatoreRepository.save(giocatore);

	            model.addAttribute("giocatore", giocatore);
	            model.addAttribute("userDetails", this.userService.getUserDetails());
	            return "index.html";
	        }
	        else {
	            return "/admin/formNewGiocatore.html";
	        }
	    }
	  
	  @GetMapping("/admin/manageSquadre")
	    public String manageSquadre(Model model){
	        model.addAttribute("squadre", this.squadraRepository.findAll());
	        return "/admin/manageSquadre.html";
	    }
	  

	    @Transactional
	    @GetMapping("/admin/formUpdateSquadra/{id}") 
	    public String formUpdateSquadra(@PathVariable("id") Long id, Model model){
	        model.addAttribute("squadra", this.squadraRepository.findById(id).get());
	        return "/admin/formUpdateSquadra.html";
	    }
	    
	    @Transactional
	    @GetMapping("/admin/editDetailsToSquadra/{id}")  
	    public String editDetails(@PathVariable("id") Long id,Model model ){

	        model.addAttribute("squadra", this.squadraRepository.findById(id).get());

	        return "/admin/formUpdateDetailsToSquadra.html";
	    }
	    
	    
	    @PostMapping("/admin/uploadSquadra1/{id}")
		 public String editDetailsToSquadra(@PathVariable("id") Long id, Model model, @Valid @ModelAttribute("squadra") Squadra squadra, BindingResult bindingResult){       
			 this.squadraValidator.validate(squadra,bindingResult);
			 if(!bindingResult.hasErrors()){
				 model.addAttribute("squadra", squadra);
				 model.addAttribute("userDetails", this.userService.getUserDetails());
				 this.squadraService.editDetailsToSquadra(squadra); 
				 return "squadra.html";
			 } 
			 	 return "/admin/indexAdmin.html";
//				 return "/admin/formUpdateDetailsToSquadra.html";
			 
		 }
	    
	    @Transactional
	    public Set<Giocatore> giocatoriToAdd(Long squadraId){
	        Set<Giocatore> giocatoriToAdd= new HashSet<Giocatore>();
//	        giocatoriToAdd = this.giocatoreRepository.getBySquadreNotContains(this.squadraRepository.findById(squadraId).get());
	        for(Giocatore g : this.giocatoreRepository.findAll()) {
	        	if(g.getSquadra()==null) {
	        		giocatoriToAdd.add(g);
	        	}
	        }

	        return giocatoriToAdd;
	    }
	    
	   @Transactional
	    @GetMapping("/admin/updateGiocatoriOnSquadra/{id}")  
	    public String updateGiocatori(@PathVariable("id") Long id,Model model ){

	        Set<Giocatore> giocatoriToAdd = this.giocatoriToAdd(id);
	        model.addAttribute("squadra", this.squadraRepository.findById(id).get());
	        model.addAttribute("giocatoriToAdd", giocatoriToAdd);

	        return "/admin/giocatoriToAdd.html";
	    }
	    
	    @Transactional
	    @GetMapping("/admin/addGiocatoreToSquadra/{giocatoreId}/{squadraId}")
	    public String addGiocatoreToSquadra(@PathVariable("giocatoreId") Long giocatoreId, @PathVariable("squadraId") Long squadraId, Model model){
	        Squadra squadra = this.squadraRepository.findById(squadraId).get();
	        this.squadraService.setGiocatoreToSquadra(squadra, giocatoreId);

	        model.addAttribute("squadra", squadra);
	        model.addAttribute("giocatoriToAdd", giocatoriToAdd(squadraId));

	        return "/admin/giocatoriToAdd.html";
	    }
	    
	    @Transactional
	    @GetMapping("/admin/removeGiocatoreFromSquadra/{giocatoreId}/{squadraId}")
	    public String removeGiocatoreFromSquadra(@PathVariable("giocatoreId") Long giocatoreId, @PathVariable("squadraId") Long squadraId, Model model){
	        Squadra squadra = this.squadraRepository.findById(squadraId).get();

	        this.squadraService.removeGiocatoreToSquadra(squadra, giocatoreId);

	        model.addAttribute("squadra", squadra);
	        model.addAttribute("giocatoriToAdd", giocatoriToAdd(squadraId));
	        
	        return "/admin/giocatoriToAdd.html";
	    }
	    @PostMapping("/admin/addGiocatoreToSquadra/{giocatoreId}/{squadraId}")
	    public String addGiocatoreToSquadra(@PathVariable("giocatoreId") Long giocatoreId, @PathVariable("squadraId") Long squadraId, Model model, Principal principal) {
	        Squadra squadra = this.squadraRepository.findById(squadraId).orElse(null);
	        if (squadra == null) {
	            // Gestisci il caso in cui la squadra non esiste
	            return "errorPage"; // Pagina di errore personalizzata o reindirizzamento a una pagina appropriata
	        }

	        // Verifica se il presidente ha il permesso di gestire i giocatori della squadra
	        String username = principal.getName();
	        User presidente = userService.findByUsername(username); // Supponendo che tu abbia un servizio per gestire gli utenti
	        if (!giocatoreService.haPermessoDiGestireGiocatori(presidente, squadraId)) {
	            // Il presidente non ha il permesso, mostra un messaggio di errore o reindirizza a una pagina appropriata
	            model.addAttribute("error", "Non hai il permesso per gestire i giocatori di questa squadra.");
	            return "errorPage"; // Pagina di errore personalizzata
	        }

	        // Aggiungi il giocatore alla squadra
	        giocatoreService.addGiocatoreToSquadra(squadra, giocatoreId);

	        // Aggiorna i giocatori da aggiungere nella vista
	        model.addAttribute("squadra", squadra);
	        model.addAttribute("giocatoriToAdd", giocatoreService.giocatoriToAdd(squadraId));

	        return "/admin/giocatoriToAdd.html"; // Reindirizzamento alla vista dei giocatori
	    }

	    @PostMapping("/admin/removeGiocatoreFromSquadra/{giocatoreId}/{squadraId}")
	    public String removeGiocatoreFromSquadra(@PathVariable("giocatoreId") Long giocatoreId, @PathVariable("squadraId") Long squadraId, Model model, Principal principal) {
	        Squadra squadra = this.squadraRepository.findById(squadraId).orElse(null);
	        if (squadra == null) {
	            // Gestisci il caso in cui la squadra non esiste
	            return "error.html"; // Pagina di errore personalizzata o reindirizzamento a una pagina appropriata
	        }

	        // Verifica se il presidente ha il permesso di gestire i giocatori della squadra
	        String username = principal.getName();
	        User presidente = userService.findByUsername(username); // Supponendo che tu abbia un servizio per gestire gli utenti
	        if (!giocatoreService.haPermessoDiGestireGiocatori(presidente, squadraId)) {
	            // Il presidente non ha il permesso, mostra un messaggio di errore o reindirizza a una pagina appropriata
	            model.addAttribute("error", "Non hai il permesso per gestire i giocatori di questa squadra.");
	            return "error.html"; // Pagina di errore personalizzata
	        }

	        // Rimuovi il giocatore dalla squadra
	        giocatoreService.removeGiocatoreFromSquadra(squadra, giocatoreId);

	        // Aggiorna i giocatori da aggiungere nella vista
	        model.addAttribute("squadra", squadra);
	        model.addAttribute("giocatoriToAdd", giocatoreService.giocatoriToAdd(squadraId));

	        return "/admin/giocatoriToAdd.html"; // Reindirizzamento alla vista dei giocatori
	    }
}