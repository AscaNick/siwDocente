package it.uniroma3.siw.controller.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.model.Giocatore;

import it.uniroma3.siw.repository.GiocatoreRepository;

@Component
public class GiocatoreValidator implements Validator{
	
	 @Autowired
	 private GiocatoreRepository giocatoreRepository;

	@Override
	public boolean supports(Class<?> clazz) {
		return Giocatore.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		Giocatore giocatore = (Giocatore) target;
        if(giocatore.getNome() != null && giocatore.getCognome() != null
            && this.giocatoreRepository.existsByNomeAndCognome(giocatore.getNome(), giocatore.getCognome())){
            errors.reject("giocatore.duplicate");
        }
		
	}
}
