package it.uniroma3.siw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocenteGennaio1Application {

	public static void main(String[] args) {
		SpringApplication.run(DocenteGennaio1Application.class, args);
	}

}
