package it.uniroma3.siw.repository;

import java.util.Set;

import org.springframework.data.repository.CrudRepository;


import it.uniroma3.siw.model.Giocatore;
import it.uniroma3.siw.model.Squadra;

public interface GiocatoreRepository extends CrudRepository<Giocatore,Long>{

	boolean existsByNomeAndCognome(String nome, String cognome);


//	Set<Giocatore> getBySquadreNotContains(Squadra squadra);




	//Set<Giocatore> getBySquadraNotContains(Squadra squadra);

}
