package it.uniroma3.siw.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Giocatore;
import it.uniroma3.siw.model.Squadra;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.GiocatoreRepository;
import it.uniroma3.siw.repository.SquadraRepository;

@Service
public class GiocatoreService {
	
	@Autowired
	private GiocatoreRepository giocatoreRepository;
	@Autowired
	private SquadraRepository squadraRepository;

    @Autowired
    private PresidenteService presidenteService; // Servizio per gestire i presidenti

    @Autowired
    private SquadraService squadraService; // Servizio per gestire le squadre

    public boolean haPermessoDiGestireGiocatori(User presidente, Long squadraId) {
        // Verifica se l'utente è un presidente
        if (presidente.getRole() != null && presidente.getRole().equals("PRESIDENTE_ROLE")) {
            // Ottieni la squadra associata al presidente
            Squadra squadra = presidenteService.findSquadraByPresidenteId(presidente.getId()); // Metodo per trovare la squadra associata a un presidente

            // Verifica se la squadra associata al presidente è la stessa della squadra passata come parametro
            if (squadra != null && squadra.getId().equals(squadraId)) {
                return true; // Il presidente ha il permesso di gestire i giocatori della sua squadra
            }
        }
        return false; // Il presidente non ha il permesso di gestire i giocatori della squadra specificata
    }

    public void addGiocatoreToSquadra(Squadra squadra, Long giocatoreId) {
        Giocatore giocatore = giocatoreRepository.findById(giocatoreId).orElse(null);
        if (giocatore != null) {
            giocatore.setSquadra(squadra);
            giocatoreRepository.save(giocatore);
        }
    }

    public Set<Giocatore> giocatoriToAdd(Long squadraId) {
        Set<Giocatore> giocatoriToAdd = new HashSet<>();
        Squadra squadra = squadraRepository.findById(squadraId).orElse(null);
        if (squadra != null) {
            // Ottieni tutti i giocatori che non hanno una squadra associata
            for (Giocatore giocatore : giocatoreRepository.findAll()) {
                if (giocatore.getSquadra() == null) {
                    giocatoriToAdd.add(giocatore);
                }
            }
        }
        return giocatoriToAdd;
    }
    public void removeGiocatoreFromSquadra(Squadra squadra, Long giocatoreId) {
        Giocatore giocatore = giocatoreRepository.findById(giocatoreId).orElse(null);
        if (giocatore != null && giocatore.getSquadra() != null && giocatore.getSquadra().equals(squadra)) {
            giocatore.setSquadra(null);
            giocatoreRepository.save(giocatore);
        }
    }

   
}
