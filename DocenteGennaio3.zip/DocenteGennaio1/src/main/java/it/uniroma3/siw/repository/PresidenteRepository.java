package it.uniroma3.siw.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import it.uniroma3.siw.model.Presidente;
import it.uniroma3.siw.model.Squadra;

public interface PresidenteRepository extends CrudRepository<Presidente,Long>{

	boolean existsByNomeAndCognome(String nome, String cognome);

	@Query("SELECT p.squadra FROM Presidente p WHERE p.id = :presidenteId")
    Squadra findSquadraByPresidenteId(@Param("presidenteId") Long presidenteId);

}
