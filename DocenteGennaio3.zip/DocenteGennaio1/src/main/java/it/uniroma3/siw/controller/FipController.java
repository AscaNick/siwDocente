package it.uniroma3.siw.controller;



import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.uniroma3.siw.controller.validator.CredentialsValidator;
import it.uniroma3.siw.controller.validator.UserValidator;
import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Giocatore;
import it.uniroma3.siw.model.Presidente;
import it.uniroma3.siw.model.Squadra;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.GiocatoreRepository;
import it.uniroma3.siw.repository.SquadraRepository;
import it.uniroma3.siw.service.CredentialsService;
import it.uniroma3.siw.service.PresidenteService;
import it.uniroma3.siw.service.SquadraService;
import it.uniroma3.siw.service.UserService;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Controller
public class FipController {
	@Autowired
	private UserValidator userValidator;
	@Autowired
	private GiocatoreRepository giocatoreRepository;

	@Autowired
	private CredentialsValidator credentialsValidator;
	@Autowired
	private UserService userService;
	@Autowired
	private SquadraRepository squadraRepository;
	@Autowired
	private CredentialsService credentialsService;
	@Autowired
	private SquadraService squadraService;
	@Autowired
	private PresidenteService presidenteService;
	
	@GetMapping("/")
	public String index(Model model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = null;
		Credentials credentials = null;
		if(!(authentication instanceof AnonymousAuthenticationToken)){
			userDetails = (UserDetails)authentication.getPrincipal();
			credentials = this.credentialsService.getCredentials(userDetails.getUsername());
		}
		if(credentials != null && credentials.getRole().equals(Credentials.ADMIN_ROLE)) return "admin/indexAdmin.html";

	/*	model.addAttribute("userDetails", userDetails);  */
		model.addAttribute("squadre", this.squadraRepository.findAll());
		return "index.html";
	}
	@GetMapping("/index")
	public String index2(Model model){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = null;
		Credentials credentials = null;
		if(!(authentication instanceof AnonymousAuthenticationToken)){
			userDetails = (UserDetails)authentication.getPrincipal();
			credentials = credentialsService.getCredentials(userDetails.getUsername());
		}
		if(credentials != null && credentials.getRole().equals(Credentials.ADMIN_ROLE)) return "admin/indexAdmin.html";

		model.addAttribute("userDetails", userDetails);
		model.addAttribute("squadre", this.squadraRepository.findAll());
		return "index.html";
	}

	@GetMapping(value = "/login")
	public String showLoginForm (Model model) {
		return "formLogin.html";
	}

	@GetMapping(value = "/register")
	public String showRegisterForm(Model model) {
	    model.addAttribute("user", new User());
	    model.addAttribute("credentials", new Credentials());
	    
	    // Recupera tutte le squadre dal servizio TeamService
	    Iterable<Squadra> squadre = squadraService.findAllSquadre();
	    // Aggiungi le squadre al modello
	    model.addAttribute("squadre", squadre);
	    
	    return "formRegister.html";
	}
/*	@PostMapping("/register")
	public String registerUser(@Valid @ModelAttribute("user") User user,
			BindingResult userBindingResult, @Valid
			@ModelAttribute("credentials") Credentials credentials,
			BindingResult credentialsBindingResult,
			Model model) {
		this.userValidator.validate(user,userBindingResult);
		this.credentialsValidator.validate(credentials, credentialsBindingResult);                        
		if(!userBindingResult.hasErrors() && ! credentialsBindingResult.hasErrors()) {
			credentials.setUser(user);
			credentialsService.saveCredentials(credentials);
			userService.saveUser(user);
			model.addAttribute("user", user);
			return "formLogin.html";
		}
		return "formRegister.html";
}*/
	@PostMapping("/register")
	public String registerUser(@Valid @ModelAttribute("user") User user,
	                           BindingResult userBindingResult,
	                           @Valid @ModelAttribute("credentials") Credentials credentials,
	                           BindingResult credentialsBindingResult,
	                           @RequestParam(value = "isPresident", required = false) boolean isPresident,
	                           @RequestParam("squadra") Long squadraId,
	                           Model model) {
	    this.userValidator.validate(user, userBindingResult);
	    this.credentialsValidator.validate(credentials, credentialsBindingResult);

	    if (!userBindingResult.hasErrors() && !credentialsBindingResult.hasErrors()) {
	        if (isPresident) {
	            credentials.setRole(Credentials.PRESIDENTE_ROLE);
	            user.setRole(User.PRESIDENTE_ROLE);
	            // Associa l'utente come presidente alla squadra selezionata
	            Optional<Squadra> optionalSquadra = squadraService.findById(squadraId);
	            Squadra squadra = optionalSquadra.orElseThrow(() -> new IllegalArgumentException("Squadra non trovata")); // Lanciare un'eccezione se la squadra non è presente
	            Presidente presidente = new Presidente();
	            presidente.setNome(user.getName());
	            presidente.setCognome(user.getSurname());
	           
	            presidente.setSquadra(squadra);
	            presidenteService.savePresidente(presidente);
	        } else {
	            credentials.setRole(Credentials.DEFAULT_ROLE);
	            user.setRole(User.DEFAULT_ROLE);
	        }

	        credentials.setUser(user);
	        credentialsService.saveCredentials(credentials);
	        userService.saveUser(user);
	        model.addAttribute("user", user);
	        return "formLogin.html";
	    }
	    return "formRegister.html";
	}
	
	
	
	
	
	@GetMapping("/squadre")
	public String squadre(Model model){

		model.addAttribute("squadre", this.squadraRepository.findAll());
		return "squadre.html";
	}

	@GetMapping("/giocatori")
	public String giocatori(Model model){

		model.addAttribute("giocatori", this.giocatoreRepository.findAll());
		return "giocatori.html";
	}
	@GetMapping("/giocatore/{id}")
	public String giocatore(@PathVariable("id") Long id, Model model){

		model.addAttribute("userDetails", this.userService.getUserDetails());

		Giocatore giocatore = this.giocatoreRepository.findById(id).get();
		model.addAttribute("giocatore", giocatore);

		return "giocatore.html";
	}

	@GetMapping("/squadra/{id}")
	public String squadra(@PathVariable("id") Long id, Model model) {
	    UserDetails userDetails = this.userService.getUserDetails();
	    model.addAttribute("userDetails", userDetails);

	    Squadra squadra = this.squadraRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Squadra non trovata"));
	    model.addAttribute("squadra", squadra);

	    // Verifica se l'utente è il presidente della squadra
	    if (userDetails != null && userDetails instanceof Presidente && ((Presidente) userDetails).getSquadra() != null && ((Presidente) userDetails).getSquadra().getId().equals(id)) {
	        return "redirect:/admin/updateGiocatoriOnSquadra/" + id;
	    }

	    if (userDetails != null && this.credentialsService.getCredentials(userDetails.getUsername()).getRole().equals(Credentials.ADMIN_ROLE)) {
	        model.addAttribute("admin", true);
	    }

	    return "squadra.html";
	}
	

	
}
